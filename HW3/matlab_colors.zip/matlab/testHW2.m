clc;
clear all;
close all;



A = [0 0 1 1 0 0; 0 0 1 0 0 0 ; 1 1 0 0 1 1;1 0 0 0 0 0 ;0 0 1 0 0 0; 0 0 1 0 0 0]
w = [1,2,3,4,5]

sumprod(A,w,10)
maxprod(A,w,10)

