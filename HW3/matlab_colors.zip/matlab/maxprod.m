function [myBMax] = maxprod(A,w,its)

% This function works for coloring problem using edges as the cliques.
% For making sure of everything please see lecture slides Approximate MAP
% Inference and Variational Inference.

m = size(A,1); % m is the number of variables in the input graph.
Values = 1:length(w); % possible lables for each random variable
k = length(Values); %number of colors

% Initial Nodes
% Each node, or variable, has to have a list of neighbors and a matrix of
% incoming messages. Each message is a function of the assigned value to
% the message reciver and the lable of the sender. So the matrix of reciving messages is a k by m matrix.
for i = 1:m
    node(i).label = i;
    node(i).Neighbors = find(A(i,:)~=0);
    node(i).Messages = zeros(k,m); %initial messages matrix.
    node(i).Messages(:,node(i).Neighbors) = 1; % initial messages from neighbors by 1.
end
%Normalize Messages.
%Normalizing is always among incoming messages of each variable from a particular neighbor. So
%For each variable
for i = 1:m
    node(i).Messages = node(i).Messages ./ repmat(sum(node(i).Messages),k,1);
    % This line of code is equal to the below for loop
    %     %For each neighbor of i
    %     for j = node(i).Neighbors
    %         node(i).Messages(:,j) = node(i).Messages(:,j)./sum(node(i).Messages(:,j));
    %     end
end
for i = 1:m
    % In each iteration, we use the previously calculated messages
    % to calculate new ones, then we upgrade all the messages at once.
    node(i).MessagesOld = node(i).Messages;
end
%%
%Start Iterations
for it = 1:its
    %For each variable
    for i = 1:m
        %For each possible value of variable i
        for x_i = Values
            %For each each neighbor of i
            
            for j = node(i).Neighbors
                myMax = -1000000;
                %For each possible value of j which is not equal to the
                %assignen value of i (because psi(x_i,x_i) = 0)
                % Here, instead of having psi(x_i,x_i) = 0, we just remove
                % x_j = x_i from our calculation using setdiff
                for x_j = setdiff(Values,x_i)
                    %Pick all the neighbors of j, but i
                    NsOfJ = setdiff(node(j).Neighbors,i);
                    nProd = 1;
                    %Get the product of income messages to j
                    for nei = NsOfJ
                        nProd = nProd*node(j).MessagesOld(x_j,nei);
                    end
                    %multiply the resulted product to the phi(x_j)
                    if phi(w(x_j))*nProd*(x_i~=x_j) > myMax
                        myMax = phi(w(x_j))*nProd*(x_i~=x_j);
                    end
                end
                %Set the income message of node i from j by having x_i as assignment
                node(i).Messages(x_i,j) = myMax;
            end
        end
    end
    %Normalize Messages in each iteration
    for i = 1:m
        node(i).Messages = node(i).Messages ./ repmat(sum(node(i).Messages),k,1);
        node(i).MessagesOld = node(i).Messages;
    end
end

%%
%Calculating believes of variables
% For each variable
% See the details on lecture slide Approximate MAP Inference
for i = 1:m
    % For each possible value of variable i
    for x_i = Values
        node(i).Belief(x_i) = phi(w(x_i))*prod(node(i).Messages(x_i,node(i).Neighbors));
    end
    node(i).Belief = node(i).Belief./(sum(node(i).Belief));
end

% For each edge (in this code we take edges as our cliques)
for i = 1:m
    for j = node(i).Neighbors
        for x_i = Values
            for x_j = setdiff(Values,x_i)
                % These 4 fors are assigning all possible assignments to
                % all the existing edges.
                % The belief of each clique is a function of its assignmnet
                edge(i,j).Belief(x_i,x_j) = phi(w(x_i))*phi(w(x_j))*...
                    prod(node(i).Messages(x_i,setdiff(node(i).Neighbors,j)))*...
                    prod(node(j).Messages(x_j,setdiff(node(j).Neighbors,i)));
            end
        end
        % Normalizing the beliefs of edge (i,j)
        edge(i,j).Belief = edge(i,j).Belief./(sum(sum(edge(i,j).Belief)));
    end
end

%%

% In this particular assignment, you are supposed to return the assignment
% that maximizes each singleton belief as a vector whose ith entry corresponds
% to the maximizing assignment of the belief for the vertex i.
% It means that for each variable find out which assignmnet gives the
% maximum belief to each node and report it as your MAP assignment.
myBMax = zeros(m,1);
for i = 1:m
    % If there is more that one maximaizer, report 0
    if length(find(node(i).Belief == max(node(i).Belief))) == 1
        myBMax(i) = find(node(i).Belief == max(node(i).Belief));
    else
        myBMax(i) = 0;
    end
end


function [out] = phi(px)
out = exp(px);

